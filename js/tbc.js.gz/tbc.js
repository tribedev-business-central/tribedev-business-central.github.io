﻿window.tbcScript = {
    showSubsiteModal: () => {
        $("#subSiteModal").modal("show");
    },
    closeSubsiteModal: () => {
        $("#subSiteModal").modal("hide");
    }
}